package org.opencv.test.ml;

import org.opencv.ml.CvStatModel;

import junit.framework.TestCase;

public class CvStatModelTest extends TestCase {

    public void testCvStatModel() {
        new CvStatModel();
    }

    public void testLoadString() {
        fail("Not yet implemented");
    }

    public void testLoadStringString() {
        fail("Not yet implemented");
    }

    public void testSaveString() {
        fail("Not yet implemented");
    }

    public void testSaveStringString() {
        fail("Not yet implemented");
    }

}
