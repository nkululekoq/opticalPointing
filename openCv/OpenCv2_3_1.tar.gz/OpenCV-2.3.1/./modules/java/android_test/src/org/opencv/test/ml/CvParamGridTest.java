package org.opencv.test.ml;

import org.opencv.ml.CvParamGrid;

import junit.framework.TestCase;

public class CvParamGridTest extends TestCase {

    public void testCvParamGrid() {
        new CvParamGrid();
    }

    public void testGet_max_val() {
        fail("Not yet implemented");
    }

    public void testGet_min_val() {
        fail("Not yet implemented");
    }

    public void testGet_step() {
        fail("Not yet implemented");
    }

    public void testSet_max_val() {
        fail("Not yet implemented");
    }

    public void testSet_min_val() {
        fail("Not yet implemented");
    }

    public void testSet_step() {
        fail("Not yet implemented");
    }

}
