package org.opencv.test.ml;

import org.opencv.ml.CvEMParams;

import junit.framework.TestCase;

public class CvEMParamsTest extends TestCase {

    public void testCvEMParams() {
        new CvEMParams();
    }

    public void testGet_cov_mat_type() {
        fail("Not yet implemented");
    }

    public void testGet_nclusters() {
        fail("Not yet implemented");
    }

    public void testGet_start_step() {
        fail("Not yet implemented");
    }

    public void testSet_cov_mat_type() {
        fail("Not yet implemented");
    }

    public void testSet_nclusters() {
        fail("Not yet implemented");
    }

    public void testSet_start_step() {
        fail("Not yet implemented");
    }

}
