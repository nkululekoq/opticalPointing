package org.opencv.test.ml;

import org.opencv.ml.CvDTreeParams;

import junit.framework.TestCase;

public class CvDTreeParamsTest extends TestCase {

    public void testCvDTreeParams() {
        new CvDTreeParams();
    }

    public void testGet_cv_folds() {
        fail("Not yet implemented");
    }

    public void testGet_max_categories() {
        fail("Not yet implemented");
    }

    public void testGet_max_depth() {
        fail("Not yet implemented");
    }

    public void testGet_min_sample_count() {
        fail("Not yet implemented");
    }

    public void testGet_regression_accuracy() {
        fail("Not yet implemented");
    }

    public void testGet_truncate_pruned_tree() {
        fail("Not yet implemented");
    }

    public void testGet_use_1se_rule() {
        fail("Not yet implemented");
    }

    public void testGet_use_surrogates() {
        fail("Not yet implemented");
    }

    public void testSet_cv_folds() {
        fail("Not yet implemented");
    }

    public void testSet_max_categories() {
        fail("Not yet implemented");
    }

    public void testSet_max_depth() {
        fail("Not yet implemented");
    }

    public void testSet_min_sample_count() {
        fail("Not yet implemented");
    }

    public void testSet_regression_accuracy() {
        fail("Not yet implemented");
    }

    public void testSet_truncate_pruned_tree() {
        fail("Not yet implemented");
    }

    public void testSet_use_1se_rule() {
        fail("Not yet implemented");
    }

    public void testSet_use_surrogates() {
        fail("Not yet implemented");
    }

}
