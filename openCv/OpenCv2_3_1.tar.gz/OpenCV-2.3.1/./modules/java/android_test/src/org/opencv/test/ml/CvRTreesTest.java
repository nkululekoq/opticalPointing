package org.opencv.test.ml;

import org.opencv.ml.CvRTrees;

import junit.framework.TestCase;

public class CvRTreesTest extends TestCase {

    public void testClear() {
        fail("Not yet implemented");
    }

    public void testCvRTrees() {
        new CvRTrees();
    }

    public void testGetVarImportance() {
        fail("Not yet implemented");
    }

    public void testPredict_probMat() {
        fail("Not yet implemented");
    }

    public void testPredict_probMatMat() {
        fail("Not yet implemented");
    }

    public void testPredictMat() {
        fail("Not yet implemented");
    }

    public void testPredictMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMatMatCvRTParams() {
        fail("Not yet implemented");
    }

}
