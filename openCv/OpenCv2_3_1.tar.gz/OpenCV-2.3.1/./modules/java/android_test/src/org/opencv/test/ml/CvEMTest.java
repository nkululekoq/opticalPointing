package org.opencv.test.ml;

import org.opencv.ml.CvEM;

import junit.framework.TestCase;

public class CvEMTest extends TestCase {

    public void testCalcLikelihood() {
        fail("Not yet implemented");
    }

    public void testClear() {
        fail("Not yet implemented");
    }

    public void testCvEM() {
        new CvEM();
    }

    public void testCvEMMat() {
        fail("Not yet implemented");
    }

    public void testCvEMMatMat() {
        fail("Not yet implemented");
    }

    public void testCvEMMatMatCvEMParams() {
        fail("Not yet implemented");
    }

    public void testGetCovs() {
        fail("Not yet implemented");
    }

    public void testGetLikelihood() {
        fail("Not yet implemented");
    }

    public void testGetLikelihoodDelta() {
        fail("Not yet implemented");
    }

    public void testGetMeans() {
        fail("Not yet implemented");
    }

    public void testGetNClusters() {
        fail("Not yet implemented");
    }

    public void testGetProbs() {
        fail("Not yet implemented");
    }

    public void testGetWeights() {
        fail("Not yet implemented");
    }

    public void testPredictMat() {
        fail("Not yet implemented");
    }

    public void testPredictMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatCvEMParams() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatCvEMParamsMat() {
        fail("Not yet implemented");
    }

}
