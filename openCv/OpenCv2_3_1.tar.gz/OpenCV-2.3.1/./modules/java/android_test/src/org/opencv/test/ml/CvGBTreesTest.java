package org.opencv.test.ml;

import org.opencv.ml.CvGBTrees;

import junit.framework.TestCase;

public class CvGBTreesTest extends TestCase {

    public void testClear() {
        fail("Not yet implemented");
    }

    public void testCvGBTrees() {
        new CvGBTrees();
    }

    public void testCvGBTreesMatIntMat() {
        fail("Not yet implemented");
    }

    public void testCvGBTreesMatIntMatMat() {
        fail("Not yet implemented");
    }

    public void testCvGBTreesMatIntMatMatMat() {
        fail("Not yet implemented");
    }

    public void testCvGBTreesMatIntMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testCvGBTreesMatIntMatMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testCvGBTreesMatIntMatMatMatMatMatCvGBTreesParams() {
        fail("Not yet implemented");
    }

    public void testPredictMat() {
        fail("Not yet implemented");
    }

    public void testPredictMatMat() {
        fail("Not yet implemented");
    }

    public void testPredictMatMatRange() {
        fail("Not yet implemented");
    }

    public void testPredictMatMatRangeInt() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMatMatCvGBTreesParams() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMatMatCvGBTreesParamsBoolean() {
        fail("Not yet implemented");
    }

}
