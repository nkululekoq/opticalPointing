package org.opencv.test.ml;

import org.opencv.ml.CvDTree;

import junit.framework.TestCase;

public class CvDTreeTest extends TestCase {

    public void testClear() {
        fail("Not yet implemented");
    }

    public void testCvDTree() {
        new CvDTree();
    }

    public void testGetVarImportance() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMatMatCvDTreeParams() {
        fail("Not yet implemented");
    }

}
