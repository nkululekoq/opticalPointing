package org.opencv.test.ml;

import org.opencv.ml.CvANN_MLP;

import junit.framework.TestCase;

public class CvANN_MLPTest extends TestCase {

    public void testClear() {
        fail("Not yet implemented");
    }

    public void testCreateMat() {
        fail("Not yet implemented");
    }

    public void testCreateMatInt() {
        fail("Not yet implemented");
    }

    public void testCreateMatIntDouble() {
        fail("Not yet implemented");
    }

    public void testCreateMatIntDoubleDouble() {
        fail("Not yet implemented");
    }

    public void testCvANN_MLP() {
        new CvANN_MLP();
    }

    public void testCvANN_MLPMat() {
        fail("Not yet implemented");
    }

    public void testCvANN_MLPMatInt() {
        fail("Not yet implemented");
    }

    public void testCvANN_MLPMatIntDouble() {
        fail("Not yet implemented");
    }

    public void testCvANN_MLPMatIntDoubleDouble() {
        fail("Not yet implemented");
    }

    public void testPredict() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMatMatCvANN_MLP_TrainParams() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMatMatCvANN_MLP_TrainParamsInt() {
        fail("Not yet implemented");
    }

}
