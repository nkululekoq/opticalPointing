package org.opencv.test.ml;

import org.opencv.ml.CvGBTreesParams;

import junit.framework.TestCase;

public class CvGBTreesParamsTest extends TestCase {

    public void testCvGBTreesParams() {
        new CvGBTreesParams();
    }

    public void testGet_loss_function_type() {
        fail("Not yet implemented");
    }

    public void testGet_shrinkage() {
        fail("Not yet implemented");
    }

    public void testGet_subsample_portion() {
        fail("Not yet implemented");
    }

    public void testGet_weak_count() {
        fail("Not yet implemented");
    }

    public void testSet_loss_function_type() {
        fail("Not yet implemented");
    }

    public void testSet_shrinkage() {
        fail("Not yet implemented");
    }

    public void testSet_subsample_portion() {
        fail("Not yet implemented");
    }

    public void testSet_weak_count() {
        fail("Not yet implemented");
    }

}
