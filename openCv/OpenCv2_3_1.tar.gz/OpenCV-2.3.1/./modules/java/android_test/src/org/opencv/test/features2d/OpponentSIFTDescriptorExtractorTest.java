package org.opencv.test.features2d;

import junit.framework.TestCase;

public class OpponentSIFTDescriptorExtractorTest extends TestCase {

    public void testComputeListOfMatListOfListOfKeyPointListOfMat() {
        fail("Not yet implemented");
    }

    public void testComputeMatListOfKeyPointMat() {
        fail("Not yet implemented");
    }

    public void testCreate() {
        fail("Not yet implemented");
    }

    public void testDescriptorSize() {
        fail("Not yet implemented");
    }

    public void testDescriptorType() {
        fail("Not yet implemented");
    }

    public void testEmpty() {
        fail("Not yet implemented");
    }

    public void testRead() {
        fail("Not yet implemented");
    }

    public void testWrite() {
        fail("Not yet implemented");
    }

}
