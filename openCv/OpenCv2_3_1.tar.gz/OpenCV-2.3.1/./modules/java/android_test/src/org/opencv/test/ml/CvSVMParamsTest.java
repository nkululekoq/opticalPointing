package org.opencv.test.ml;

import org.opencv.ml.CvSVMParams;

import junit.framework.TestCase;

public class CvSVMParamsTest extends TestCase {

    public void testCvSVMParams() {
        new CvSVMParams();
    }

    public void testGet_C() {
        fail("Not yet implemented");
    }

    public void testGet_coef0() {
        fail("Not yet implemented");
    }

    public void testGet_degree() {
        fail("Not yet implemented");
    }

    public void testGet_gamma() {
        fail("Not yet implemented");
    }

    public void testGet_kernel_type() {
        fail("Not yet implemented");
    }

    public void testGet_nu() {
        fail("Not yet implemented");
    }

    public void testGet_p() {
        fail("Not yet implemented");
    }

    public void testGet_svm_type() {
        fail("Not yet implemented");
    }

    public void testSet_C() {
        fail("Not yet implemented");
    }

    public void testSet_coef0() {
        fail("Not yet implemented");
    }

    public void testSet_degree() {
        fail("Not yet implemented");
    }

    public void testSet_gamma() {
        fail("Not yet implemented");
    }

    public void testSet_kernel_type() {
        fail("Not yet implemented");
    }

    public void testSet_nu() {
        fail("Not yet implemented");
    }

    public void testSet_p() {
        fail("Not yet implemented");
    }

    public void testSet_svm_type() {
        fail("Not yet implemented");
    }

}
