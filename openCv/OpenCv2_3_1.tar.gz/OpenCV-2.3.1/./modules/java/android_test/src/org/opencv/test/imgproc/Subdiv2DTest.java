package org.opencv.test.imgproc;

import org.opencv.test.OpenCVTestCase;

public class Subdiv2DTest extends OpenCVTestCase {

    protected void setUp() throws Exception {
        super.setUp();
    }

    public void testEdgeDstInt() {
        fail("Not yet implemented");
    }

    public void testEdgeDstIntPoint() {
        fail("Not yet implemented");
    }

    public void testEdgeOrgInt() {
        fail("Not yet implemented");
    }

    public void testEdgeOrgIntPoint() {
        fail("Not yet implemented");
    }

    public void testFindNearestPoint() {
        fail("Not yet implemented");
    }

    public void testFindNearestPointPoint() {
        fail("Not yet implemented");
    }

    public void testGetEdge() {
        fail("Not yet implemented");
    }

    public void testGetEdgeList() {
        fail("Not yet implemented");
    }

    public void testGetTriangleList() {
        fail("Not yet implemented");
    }

    public void testGetVertexInt() {
        fail("Not yet implemented");
    }

    public void testGetVertexIntIntArray() {
        fail("Not yet implemented");
    }

    public void testGetVoronoiFacetList() {
        fail("Not yet implemented");
    }

    public void testInitDelaunay() {
        fail("Not yet implemented");
    }

    public void testInsertListOfPoint() {
        fail("Not yet implemented");
    }

    public void testInsertPoint() {
        fail("Not yet implemented");
    }

    public void testLocate() {
        fail("Not yet implemented");
    }

    public void testNextEdge() {
        fail("Not yet implemented");
    }

    public void testRotateEdge() {
        fail("Not yet implemented");
    }

    public void testSubdiv2D() {
        fail("Not yet implemented");
    }

    public void testSubdiv2DRect() {
        fail("Not yet implemented");
    }

    public void testSymEdge() {
        fail("Not yet implemented");
    }

}
