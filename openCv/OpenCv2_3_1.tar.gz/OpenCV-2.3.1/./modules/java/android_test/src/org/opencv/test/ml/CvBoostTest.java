package org.opencv.test.ml;

import org.opencv.ml.CvBoost;

import junit.framework.TestCase;

public class CvBoostTest extends TestCase {

    public void testClear() {
        fail("Not yet implemented");
    }

    public void testCvBoost() {
        new CvBoost();
    }

    public void testCvBoostMatIntMat() {
        fail("Not yet implemented");
    }

    public void testCvBoostMatIntMatMat() {
        fail("Not yet implemented");
    }

    public void testCvBoostMatIntMatMatMat() {
        fail("Not yet implemented");
    }

    public void testCvBoostMatIntMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testCvBoostMatIntMatMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testCvBoostMatIntMatMatMatMatMatCvBoostParams() {
        fail("Not yet implemented");
    }

    public void testPredictMat() {
        fail("Not yet implemented");
    }

    public void testPredictMatMat() {
        fail("Not yet implemented");
    }

    public void testPredictMatMatRange() {
        fail("Not yet implemented");
    }

    public void testPredictMatMatRangeBoolean() {
        fail("Not yet implemented");
    }

    public void testPredictMatMatRangeBooleanBoolean() {
        fail("Not yet implemented");
    }

    public void testPrune() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMatMatCvBoostParams() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMatMatCvBoostParamsBoolean() {
        fail("Not yet implemented");
    }

}
