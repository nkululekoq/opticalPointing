package org.opencv.test.ml;

import org.opencv.ml.CvBoostParams;

import junit.framework.TestCase;

public class CvBoostParamsTest extends TestCase {

    public void testCvBoostParams() {
        new CvBoostParams();
    }

    public void testGet_boost_type() {
        fail("Not yet implemented");
    }

    public void testGet_split_criteria() {
        fail("Not yet implemented");
    }

    public void testGet_weak_count() {
        fail("Not yet implemented");
    }

    public void testGet_weight_trim_rate() {
        fail("Not yet implemented");
    }

    public void testSet_boost_type() {
        fail("Not yet implemented");
    }

    public void testSet_split_criteria() {
        fail("Not yet implemented");
    }

    public void testSet_weak_count() {
        fail("Not yet implemented");
    }

    public void testSet_weight_trim_rate() {
        fail("Not yet implemented");
    }

}
