package org.opencv.test.ml;

import org.opencv.ml.CvANN_MLP_TrainParams;

import junit.framework.TestCase;

public class CvANN_MLP_TrainParamsTest extends TestCase {

    public void testCvANN_MLP_TrainParams() {
        new CvANN_MLP_TrainParams();
    }

    public void testGet_bp_dw_scale() {
        fail("Not yet implemented");
    }

    public void testGet_bp_moment_scale() {
        fail("Not yet implemented");
    }

    public void testGet_rp_dw_max() {
        fail("Not yet implemented");
    }

    public void testGet_rp_dw_min() {
        fail("Not yet implemented");
    }

    public void testGet_rp_dw_minus() {
        fail("Not yet implemented");
    }

    public void testGet_rp_dw_plus() {
        fail("Not yet implemented");
    }

    public void testGet_rp_dw0() {
        fail("Not yet implemented");
    }

    public void testGet_train_method() {
        fail("Not yet implemented");
    }

    public void testSet_bp_dw_scale() {
        fail("Not yet implemented");
    }

    public void testSet_bp_moment_scale() {
        fail("Not yet implemented");
    }

    public void testSet_rp_dw_max() {
        fail("Not yet implemented");
    }

    public void testSet_rp_dw_min() {
        fail("Not yet implemented");
    }

    public void testSet_rp_dw_minus() {
        fail("Not yet implemented");
    }

    public void testSet_rp_dw_plus() {
        fail("Not yet implemented");
    }

    public void testSet_rp_dw0() {
        fail("Not yet implemented");
    }

    public void testSet_train_method() {
        fail("Not yet implemented");
    }

}
